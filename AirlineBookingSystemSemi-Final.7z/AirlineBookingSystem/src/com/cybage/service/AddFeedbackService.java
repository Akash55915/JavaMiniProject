package com.cybage.service;

import com.cybage.model.Feedback;

public interface AddFeedbackService {
	public boolean addFeedback(Feedback feedback);
}
