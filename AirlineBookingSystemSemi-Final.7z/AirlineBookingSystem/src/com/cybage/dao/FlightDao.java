package com.cybage.dao;

import com.cybage.model.Flight;

public interface FlightDao {
 Flight getFlightById(int flight_No);
 
}
