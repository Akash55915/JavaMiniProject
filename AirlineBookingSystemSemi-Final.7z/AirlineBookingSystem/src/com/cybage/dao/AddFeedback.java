package com.cybage.dao;

import com.cybage.model.Feedback;

public interface AddFeedback {
 public boolean addFeedback(Feedback feedback);
}
